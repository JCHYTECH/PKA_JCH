---
date: 2026-05-21
source: chat-ai
domain: électronique
project: WILDMESH
tags: [esp32, lora, orthoptères, bioacoustique, iot, raspberry-pi]
status: raw
---

# Plusieurs ESP32 en réseau — synthèse de discussion

## 1. Communication entre ESP32

Quatre approches principales :

- **ESP-NOW** : protocole propriétaire Espressif, peer-to-peer ou broadcast, ~200m en champ libre, latence ~1ms, sans infrastructure, limité à 20 pairs.
- **WiFi + MQTT** : broker central (Mosquitto sur Pi ou NAS), scalable à des dizaines de nœuds, gestion par topics.
- **ESP-MESH / OpenThread** : réseau auto-organisé, un seul nœud root connecté à internet, plus complexe à déboguer.
- **LoRa** : longue portée, faible débit, pertinent pour terrain distant.

---

## 2. Cas d'usage : caméra + capteurs + micro dans un boîtier

### Contrainte hardware principale

L'ESP32 classique (ESP32-CAM AI Thinker) utilise ~10 GPIO pour l'interface caméra DVP — très peu de pins libres pour ajouter micro et capteurs.

**Solution recommandée : ESP32-S3**
- Plus de GPIO (45 vs ~25)
- Jusqu'à 8MB PSRAM intégrée
- I2S natif mieux géré (micro)
- USB natif
- Caméra DVP supportée
- DMA moins conflictuel caméra/audio

### Déclenchement au mouvement

Simplifie considérablement : caméra et audio ne tournent pas en simultané continu. Flux :
```
Sleep profond → trigger → réveil → capture image + audio → retour sleep
```

**Capteurs de mouvement comparés :**

| Capteur | Portée | Faux positifs | Remarque |
|---|---|---|---|
| PIR HC-SR501 | 3–7m | Vent, chaleur | Classique, lent à reset |
| Radar LD2410 | ~5m | Très peu | Traverse le plastique |
| RCWL-0516 | ~7m | Moyen | Cheap, sensible |

Le radar LD2410 est intéressant pour boîtier hermétique — traverse le plastique.

---

## 3. Identification sonore par IA

### Ce que l'ESP32-S3 ne peut pas faire

Faire tourner BirdNET ou une bibliothèque d'identification riche localement :

| Ressource | BirdNET minimum | ESP32-S3 |
|---|---|---|
| RAM | ~500MB+ | 8MB PSRAM max |
| Stockage modèle | ~200-500MB | 16MB Flash typique |
| CPU | ARM Cortex-A | Xtensa LX7 240MHz |

TensorFlow Lite Micro peut faire du keyword spotting simple (<500KB), pas de l'identification multi-espèces fine.

### Architecture réaliste

```
ESP32-S3 terrain → capture audio WAV → SD / WiFi / LoRa
        ↓
Serveur / Raspberry Pi
├── BirdNET → oiseaux
├── OrthopterOSS → Orthoptères
└── Résultats loggés en base de données
```

---

## 4. Orthoptères — bibliothèques disponibles

Pas d'équivalent BirdNET clé-en-main. État du domaine :

- **ECOSoundSet** (avril 2025) : dataset 10 653 enregistrements, 200 espèces d'Orthoptères + 24 Cicadidae, couvre Belgique, France, Allemagne, Pays-Bas, Luxembourg. Dataset, pas outil plug-and-play.
- **OrthopterOSS** : classifier ML pour 17 espèces, conçu PAM Europe du nord, testé avec AudioMoth.

Pipeline envisageable : ECOSoundSet + OrthopterOSS comme base + fine-tuning sur espèces locales belges.

---

## 5. AudioMoth

Enregistreur acoustique open source (Open Acoustic Devices, UK). Standard de facto bioacoustique terrain low-cost.

- Spectre jusqu'à 384 kHz (ultrasons, chauves-souris)
- Autonomie plusieurs semaines sur piles AA
- ~70-90€
- Aucune connectivité (SD only)

**Comparaison AudioMoth vs ESP32-S3 + INMP441 :**

| | AudioMoth | ESP32-S3 + INMP441 |
|---|---|---|
| Qualité audio | Très bonne | Correcte |
| Spectre | jusqu'à 384 kHz | ~20 kHz max |
| Autonomie | Semaines | Jours |
| Connectivité | Aucune | WiFi, BLE, LoRa |
| Prix | ~80€ | ~15€ |
| Caméra intégrable | Non | Oui |

Pour les Orthoptères (2–20 kHz) : INMP441 sur ESP32 est suffisant.

---

## 6. Fréquences et limites ESP32

| Cible | Fréquences | ESP32 suffisant ? |
|---|---|---|
| Orthoptères | 2–20 kHz | Oui, largement |
| Oiseaux | 0.5–10 kHz | Oui |
| Chauves-souris | 20–120 kHz | Non |
| Plein spectre AudioMoth | jusqu'à 384 kHz | Non |

L'I2S de l'ESP32/S3 est stable jusqu'à ~96 kHz maximum. Pour chauves-souris, plateformes recommandées : AudioMoth, Teensy 4.1, Raspberry Pi + carte son externe.

---

## 7. Communication LoRa ESP32 → Raspberry Pi

**Portée cible : 1km** — trivial pour LoRa en terrain boisé belge.

| SF | Débit réel | Portée terrain boisé |
|---|---|---|
| SF7 | ~5.5 kbps | 500m–1km |
| SF8 | ~3 kbps | 1–2km |
| SF9 | ~1.7 kbps | 2–3km |

SF8 recommandé à 1km — marges confortables.

**Limites de transfert (duty cycle EU 868MHz 1%) :**

| Type données | Taille typique | LoRa viable ? |
|---|---|---|
| Télémétrie (trigger, batterie, timestamp) | quelques octets | Oui, trivial |
| Audio 5s compressé mono 8kHz | ~40KB | Lent (3-4 min) mais faisable |
| Photo JPEG | 20–100KB | Non réaliste |

**Stratégie retenue :** SD locale pour photos, LoRa pour télémétrie + audio compressé.

**Module recommandé :** Heltec WiFi LoRa 32 V3 (ESP32-S3 + SX1276 intégré, ~25-30€).

---

## 8. Architecture finale — 3 unités + 1 Pi

```
[Unité 1]          [Unité 2]          [Unité 3]
ESP32-S3+LoRa      ESP32-S3+LoRa      ESP32-S3+LoRa
     │                   │                   │
     └───────────────────┴───────────────────┘
                         │ LoRa 868MHz
                    [Raspberry Pi]
                    ├── Récepteur LoRa
                    ├── BirdNET
                    ├── OrthopterOSS
                    └── Base de données SQLite
```

Topologie star — Pi écoute les 3 nœuds. Gestion collisions : TDMA manuel (slots temporels par unité) ou CSMA.

**Structure base de données :**
```
event_id | unit_id | timestamp | espece_detectee | confidence | fichier_audio | batterie
```

**OTA via WiFi :** Le Pi crée un hotspot temporaire, les ESP32 s'y connectent pour mise à jour firmware, puis repassent en mode LoRa.

---

## 9. Boîtier terrain (unités déplaçables)

```
Boîtier étanche IP65
├── ESP32-S3 + LoRa (Heltec V3)
├── Batterie 18650 ×2 + BMS
├── Panneau solaire 5W (optionnel)
├── PIR ou LD2410 (fenêtre plastique)
├── OV2640 (hublot polycarbonate)
├── INMP441 (membrane Gore-Tex)
└── SD card 32–64GB
```

Fixation : sangle velcro arbre, ou piquet acier prairie. Hauteur 30–50cm pour Orthoptères.

Autonomie estimée (10 déclenchements/jour de 5s) : plusieurs semaines sur 2× 18650.

---

## 10. Extension mémoire ESP32-S3

| Type | Extensible ? | Méthode |
|---|---|---|
| SRAM interne (512KB) | Non | Fixe sur puce |
| PSRAM externe | Choix à l'achat | Modules 4MB / 8MB / 16MB |
| Flash | Choix à l'achat | Modules 4MB / 16MB / 32MB |
| Stockage | Oui, illimité | SD card SPI |

8MB PSRAM recommandé minimum pour buffer audio et modèle TFLite.

---

## 11. Carte SIM — connectivité cellulaire

Via module externe UART. Modules recommandés :

| Module | Réseau | Prix | Remarque |
|---|---|---|---|
| SIM800L | 2G | ~5€ | Réseau 2G éteint Belgique fin 2025 — obsolète |
| SIM7600 | 4G LTE | ~25€ | Solide, bien documenté |
| SIM7070G | LTE-M / NB-IoT | ~15€ | Idéal IoT basse consommation, couvert Proximus/Orange BE |
| A7670 | 4G LTE | ~20€ | Compact, bon support Arduino |

Architecture avec SIM comme fallback LoRa :
```
ESP32-S3
├── LoRa → Pi local (si portée)
└── SIM7070G → cloud / serveur distant (si hors portée)
```

Consommation SIM en veille : ~5–10mA — à surveiller sur batterie.

---

## 12. UART — rappel

**Universal Asynchronous Receiver-Transmitter.** Protocole série 2 fils (TX/RX + GND commun). Pas de fil d'horloge — les deux parties se synchronisent sur un baudrate convenu (9600 ou 115200 typique).

L'ESP32-S3 dispose de **3 ports UART** :
- UART0 → debug / programmation
- UART1 → module GSM (SIM7070G)
- UART2 → GPS (optionnel)

**Comparaison protocoles ESP32 :**

| Protocole | Fils | Usage typique |
|---|---|---|
| UART | 2 (TX/RX) | Modules GSM, GPS, debug |
| I2C | 2 (SDA/SCL) | Capteurs temp, pression |
| SPI | 4 (MOSI/MISO/CLK/CS) | SD card, LoRa, écrans |
| I2S | 3-4 | Audio (micro, DAC) |

---

## Ordre de développement recommandé

1. Un seul ESP32-S3 + Pi fonctionnel end-to-end (trigger → LoRa → identification)
2. Dupliquer ×3 une fois le firmware validé
3. OTA en dernier — quand tout le reste est stable

